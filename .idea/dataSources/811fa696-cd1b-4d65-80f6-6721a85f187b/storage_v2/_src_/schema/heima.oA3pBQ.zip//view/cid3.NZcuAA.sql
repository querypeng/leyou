CREATE VIEW cid3 AS
  SELECT `heima`.`tb_category`.`parent_id` AS `parent_id`
  FROM `heima`.`tb_category`
  GROUP BY `heima`.`tb_category`.`parent_id`;

